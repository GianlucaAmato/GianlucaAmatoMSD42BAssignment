#pragma once
#include "il2cpp-config.h"

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace Mono
{
namespace Unity
{
    class LIBIL2CPP_CODEGEN_API UnityTls
    {
    public:
        static const void* GetUnityTlsInterface();
    };
} /* namespace Unity */
} /* namespace Mono */
} /* namespace mscorlib */
} /* namespace icalls */
} /* namespace il2cpp */
