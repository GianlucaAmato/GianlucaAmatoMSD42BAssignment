#pragma once
#include "il2cpp-object-internals.h"

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
namespace Reflection
{
    class LIBIL2CPP_CODEGEN_API RtFieldInfo
    {
    public:
        static Il2CppObject* UnsafeGetValue(Il2CppReflectionField* _this, Il2CppObject* obj);
    };
} // namespace Reflection
} // namespace System
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp
