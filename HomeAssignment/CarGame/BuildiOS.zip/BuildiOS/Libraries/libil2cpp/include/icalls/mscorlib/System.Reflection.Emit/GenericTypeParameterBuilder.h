#pragma once

#include "il2cpp-config.h"
struct Il2CppReflectionGenericParam;

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
namespace Reflection
{
namespace Emit
{
    class LIBIL2CPP_CODEGEN_API GenericTypeParameterBuilder
    {
    public:
        static void initialize(Il2CppReflectionGenericParam* genericParameter);
    };
} /* namespace Emit */
} /* namespace Reflection */
} /* namespace System */
} /* namespace mscorlib */
} /* namespace icalls */
} /* namespace il2cpp */
