﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void BGScroll::Start()
extern void BGScroll_Start_m43855E2416C592E8F9123C7B82C0426632810E43 (void);
// 0x00000002 System.Void BGScroll::Update()
extern void BGScroll_Update_m8B0F5DB3DE39C4F9B0624180E249DC0592EE1BD3 (void);
// 0x00000003 System.Void BGScroll::.ctor()
extern void BGScroll__ctor_mFAF501D0B700247D22710CBA8015A0ED75C2035C (void);
// 0x00000004 System.Int32 DamageDealer::GetDamage()
extern void DamageDealer_GetDamage_mACE71A6C2E3690BD4B5573A247846EDDE0BF7C9A (void);
// 0x00000005 System.Void DamageDealer::Hit()
extern void DamageDealer_Hit_m25098E8BE8713BACB0B71CBCA7638785E013FD2C (void);
// 0x00000006 System.Void DamageDealer::Die()
extern void DamageDealer_Die_mBD1BF608F538507E428815B57CB7876226AF9E3C (void);
// 0x00000007 System.Void DamageDealer::.ctor()
extern void DamageDealer__ctor_m089537C3DC7DE8C9FE32928F59784268ED3B3F2A (void);
// 0x00000008 System.Void GameSession::Awake()
extern void GameSession_Awake_m7DA48EED2DD2C071B858C834D8EE6F4BAD3890E6 (void);
// 0x00000009 System.Void GameSession::Update()
extern void GameSession_Update_mC5CC7FB854246A3D506D3111D5EE6B7737D181E3 (void);
// 0x0000000A System.Void GameSession::SetUpSingleton()
extern void GameSession_SetUpSingleton_m3EBBFD4F49CBAE3FF13F8EE16DF19D53DB43DAA8 (void);
// 0x0000000B System.Void GameSession::AddToScore(System.Int32)
extern void GameSession_AddToScore_m25B41713BA1B9089BD1E3E644D71951C6DBBEE14 (void);
// 0x0000000C System.Int32 GameSession::GetScore()
extern void GameSession_GetScore_m261421177B31C07760F0942659EDCC341C24E7FD (void);
// 0x0000000D System.Void GameSession::ResetGame()
extern void GameSession_ResetGame_m5AAA74149896637E8655D08CFC4F8FA11F92A152 (void);
// 0x0000000E System.Void GameSession::PointCheck()
extern void GameSession_PointCheck_m37E733DF7529327B141B68E7987791F38D3214A3 (void);
// 0x0000000F System.Void GameSession::.ctor()
extern void GameSession__ctor_m7A23EA1283AFD52547E4A98A8B368566F0F3DC9D (void);
// 0x00000010 System.Void HealthDisplay::Start()
extern void HealthDisplay_Start_mEB17D54FB168B486E96767626AAF4E21752F040F (void);
// 0x00000011 System.Void HealthDisplay::Update()
extern void HealthDisplay_Update_m352632E07747035D6053D01EACAF7EECE5E6F5E9 (void);
// 0x00000012 System.Void HealthDisplay::.ctor()
extern void HealthDisplay__ctor_mCAE6A5E5DB1C29BF2340D5BEFEF395929317BF75 (void);
// 0x00000013 System.Collections.IEnumerator Level::WaitAndLoad()
extern void Level_WaitAndLoad_m247CF14285F9A3D2A571824CC832485FA1970CCE (void);
// 0x00000014 System.Void Level::LoadStartMenu()
extern void Level_LoadStartMenu_m1FA3148093140D616278E650D0801420CD5CA9F8 (void);
// 0x00000015 System.Void Level::LoadGame()
extern void Level_LoadGame_m37B99D4AF36E778ADFCD54326003A392941A32CB (void);
// 0x00000016 System.Void Level::LoadGameOver()
extern void Level_LoadGameOver_mD8D2FF13AD824851031F3C9396CFF0467D1BD072 (void);
// 0x00000017 System.Void Level::QuitGame()
extern void Level_QuitGame_m49D8506FD999542FDAE47BA04B556B2332A53F5D (void);
// 0x00000018 System.Void Level::PlayerWins()
extern void Level_PlayerWins_mF342E40855606963D236F8153012B99DE6267AF1 (void);
// 0x00000019 System.Void Level::.ctor()
extern void Level__ctor_mBBC9E192AD5FC6CC5FA5DFA55E8CA13E182C353A (void);
// 0x0000001A System.Void Level_<WaitAndLoad>d__1::.ctor(System.Int32)
extern void U3CWaitAndLoadU3Ed__1__ctor_m5F71A2BAEEC015A2CC4DC0721B5F7E29E8F3DF5F (void);
// 0x0000001B System.Void Level_<WaitAndLoad>d__1::System.IDisposable.Dispose()
extern void U3CWaitAndLoadU3Ed__1_System_IDisposable_Dispose_mEB8874538846D128D2BEA5DB4CE26625486C7FCB (void);
// 0x0000001C System.Boolean Level_<WaitAndLoad>d__1::MoveNext()
extern void U3CWaitAndLoadU3Ed__1_MoveNext_m9988CA5B69AF251F5259736506920CA496587712 (void);
// 0x0000001D System.Object Level_<WaitAndLoad>d__1::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWaitAndLoadU3Ed__1_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m86594924B08710474A36F8F934158923601C4CFA (void);
// 0x0000001E System.Void Level_<WaitAndLoad>d__1::System.Collections.IEnumerator.Reset()
extern void U3CWaitAndLoadU3Ed__1_System_Collections_IEnumerator_Reset_m6475A7C30FF91F5C08ECD0CE8340D0706D32D755 (void);
// 0x0000001F System.Object Level_<WaitAndLoad>d__1::System.Collections.IEnumerator.get_Current()
extern void U3CWaitAndLoadU3Ed__1_System_Collections_IEnumerator_get_Current_m4FDEEA9F719E60EA6B4EE05B443464E683F417F0 (void);
// 0x00000020 System.Void MusicPlayer::Awake()
extern void MusicPlayer_Awake_mA60904394C1725C664514BD13BA55F8CEC17D6F0 (void);
// 0x00000021 System.Void MusicPlayer::SetUpSingleton()
extern void MusicPlayer_SetUpSingleton_m19A6DE140ED2A0F7B4E06592123C60FC8CCAA60B (void);
// 0x00000022 System.Void MusicPlayer::Update()
extern void MusicPlayer_Update_m7BD87702BA93E1CE0DA8D666975B48BF5ABC376E (void);
// 0x00000023 System.Void MusicPlayer::.ctor()
extern void MusicPlayer__ctor_mA83600A144210E8586F4618ED75C614BFE6450FC (void);
// 0x00000024 System.Void ObstaclePath::Start()
extern void ObstaclePath_Start_m85867EC8D0ABD86BD834F3D26DEC616A76BFA187 (void);
// 0x00000025 System.Void ObstaclePath::Update()
extern void ObstaclePath_Update_mCDF81CAC68CBD2ACDB9D383D5C4C35B08181FE67 (void);
// 0x00000026 System.Void ObstaclePath::ObstacleMove()
extern void ObstaclePath_ObstacleMove_m66A4F8BDF7745ABEE4D3905A46DDDB95F2531D93 (void);
// 0x00000027 System.Void ObstaclePath::SetWaveConfiguration(WaveConfiguration)
extern void ObstaclePath_SetWaveConfiguration_mCADABA412E031409B2D1996B5EDE8206FFFCB057 (void);
// 0x00000028 System.Void ObstaclePath::.ctor()
extern void ObstaclePath__ctor_mB7995AD1B77C35CD3948C855656B1E52CED488DD (void);
// 0x00000029 System.Collections.IEnumerator ObstacleSpawner::Start()
extern void ObstacleSpawner_Start_mC70CACAF9BE51DD2DEA9E668B51E4D542DDC338A (void);
// 0x0000002A System.Collections.IEnumerator ObstacleSpawner::SpawnAllObstaclesInWave(WaveConfiguration)
extern void ObstacleSpawner_SpawnAllObstaclesInWave_m13A6583AD28314CCBDD63EE7C27F33FA1163DBEE (void);
// 0x0000002B System.Collections.IEnumerator ObstacleSpawner::SpawnAllWaves()
extern void ObstacleSpawner_SpawnAllWaves_mCF24E97F2DAE934D0A04AFDFB8340306A798D043 (void);
// 0x0000002C System.Void ObstacleSpawner::.ctor()
extern void ObstacleSpawner__ctor_m347D7FB8C7FAEB149F02F9A147EE7E51A28F57ED (void);
// 0x0000002D System.Void ObstacleSpawner_<Start>d__2::.ctor(System.Int32)
extern void U3CStartU3Ed__2__ctor_mEFAF09649F1D95A91B0A017558D0300F7D5A24B2 (void);
// 0x0000002E System.Void ObstacleSpawner_<Start>d__2::System.IDisposable.Dispose()
extern void U3CStartU3Ed__2_System_IDisposable_Dispose_m15038C7B9B231A52FE4EF065FB6B1B329247FD9E (void);
// 0x0000002F System.Boolean ObstacleSpawner_<Start>d__2::MoveNext()
extern void U3CStartU3Ed__2_MoveNext_mC10E97A5BF1691D20448A6A46648AAEBBFF2F5BD (void);
// 0x00000030 System.Object ObstacleSpawner_<Start>d__2::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__2_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8C4C2711353CEF85D592B351EC2AFBD253D165F0 (void);
// 0x00000031 System.Void ObstacleSpawner_<Start>d__2::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__2_System_Collections_IEnumerator_Reset_m9BDF3D9F7A5D489C24586360E8BB7818D42D0B62 (void);
// 0x00000032 System.Object ObstacleSpawner_<Start>d__2::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__2_System_Collections_IEnumerator_get_Current_mE3888933876E6E4062B1712206966E16642B7A36 (void);
// 0x00000033 System.Void ObstacleSpawner_<SpawnAllObstaclesInWave>d__3::.ctor(System.Int32)
extern void U3CSpawnAllObstaclesInWaveU3Ed__3__ctor_mF59D226A47B1AEED02FFE7AB7334F9C4B04C85E3 (void);
// 0x00000034 System.Void ObstacleSpawner_<SpawnAllObstaclesInWave>d__3::System.IDisposable.Dispose()
extern void U3CSpawnAllObstaclesInWaveU3Ed__3_System_IDisposable_Dispose_m720B77284C4922626E0405F3D49F4F9336A8BB9C (void);
// 0x00000035 System.Boolean ObstacleSpawner_<SpawnAllObstaclesInWave>d__3::MoveNext()
extern void U3CSpawnAllObstaclesInWaveU3Ed__3_MoveNext_m933598324F47DFE7B83B93174CE27258EB0E2D10 (void);
// 0x00000036 System.Object ObstacleSpawner_<SpawnAllObstaclesInWave>d__3::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CSpawnAllObstaclesInWaveU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m99AF51248408CF1347686FD783C7FAED881A77ED (void);
// 0x00000037 System.Void ObstacleSpawner_<SpawnAllObstaclesInWave>d__3::System.Collections.IEnumerator.Reset()
extern void U3CSpawnAllObstaclesInWaveU3Ed__3_System_Collections_IEnumerator_Reset_m8A947A888C19B04F7B1815E1EC7B3B3315191681 (void);
// 0x00000038 System.Object ObstacleSpawner_<SpawnAllObstaclesInWave>d__3::System.Collections.IEnumerator.get_Current()
extern void U3CSpawnAllObstaclesInWaveU3Ed__3_System_Collections_IEnumerator_get_Current_m396C65050424725F350BA5AE3E0BD17C09469F31 (void);
// 0x00000039 System.Void ObstacleSpawner_<SpawnAllWaves>d__4::.ctor(System.Int32)
extern void U3CSpawnAllWavesU3Ed__4__ctor_mB4D2C5AFA037D17EEA248003C7CFB445A6826C7F (void);
// 0x0000003A System.Void ObstacleSpawner_<SpawnAllWaves>d__4::System.IDisposable.Dispose()
extern void U3CSpawnAllWavesU3Ed__4_System_IDisposable_Dispose_m6982CFEC8B2DC3E25D4C15CC303D6D18094ECC62 (void);
// 0x0000003B System.Boolean ObstacleSpawner_<SpawnAllWaves>d__4::MoveNext()
extern void U3CSpawnAllWavesU3Ed__4_MoveNext_mD658B71A193733F1029CBBCF3D534F63FF561958 (void);
// 0x0000003C System.Void ObstacleSpawner_<SpawnAllWaves>d__4::<>m__Finally1()
extern void U3CSpawnAllWavesU3Ed__4_U3CU3Em__Finally1_m7D542661A509E7762C6725BC04599F4D71AD8A14 (void);
// 0x0000003D System.Object ObstacleSpawner_<SpawnAllWaves>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CSpawnAllWavesU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m4A31DC2E73ABFB5501DBB1139E13AFC9A0168CE9 (void);
// 0x0000003E System.Void ObstacleSpawner_<SpawnAllWaves>d__4::System.Collections.IEnumerator.Reset()
extern void U3CSpawnAllWavesU3Ed__4_System_Collections_IEnumerator_Reset_m082C690DECCB9B85D78F03D7370BBBF4177337A9 (void);
// 0x0000003F System.Object ObstacleSpawner_<SpawnAllWaves>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CSpawnAllWavesU3Ed__4_System_Collections_IEnumerator_get_Current_m7D4489F3C07BA1FA402321009DD161CC8BD4C2EB (void);
// 0x00000040 System.Void Player::Start()
extern void Player_Start_mBD692B64AAC791B93A589E7D3596F36787EAF021 (void);
// 0x00000041 System.Void Player::Update()
extern void Player_Update_mBA04F1D6FE3C18037EA95DFAEEAA9977BFD49CD3 (void);
// 0x00000042 System.Int32 Player::GetHealth()
extern void Player_GetHealth_m258C63EDD1D293DA477E9D375D04AF88598B75E5 (void);
// 0x00000043 System.Void Player::BounderiesMovement()
extern void Player_BounderiesMovement_m3FEF21D18B3136F367A413341D621711979CEB8D (void);
// 0x00000044 System.Void Player::Movement()
extern void Player_Movement_m8903F38060709B703B2329E508BA6A885AFF387B (void);
// 0x00000045 System.Void Player::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void Player_OnTriggerEnter2D_mAF357F7244427CB9EADB81B5A6C4F0AF481641D0 (void);
// 0x00000046 System.Void Player::ProcessHit(DamageDealer)
extern void Player_ProcessHit_mCBFF65ACF52F604E30DA7B868C6D57597E5A46EA (void);
// 0x00000047 System.Void Player::Die()
extern void Player_Die_m16A200929DBDF9FF88C8191A26327C2CCCC80C19 (void);
// 0x00000048 System.Void Player::.ctor()
extern void Player__ctor_mDE8EB5B351975D4E7E24DE341B8B49B8A29CC2B7 (void);
// 0x00000049 System.Void ScoreDisplay::Start()
extern void ScoreDisplay_Start_m18A9D066FCD5D2688F589FDD814B56EB48182E7F (void);
// 0x0000004A System.Void ScoreDisplay::Update()
extern void ScoreDisplay_Update_m104674478C444000FAD9F531723CB626CAD7B82F (void);
// 0x0000004B System.Void ScoreDisplay::.ctor()
extern void ScoreDisplay__ctor_m7BAE440B77B8FCE54475EBC1CDB2E82937E17496 (void);
// 0x0000004C System.Void Shooter::Start()
extern void Shooter_Start_mBA83984BC9920FA1D7FF4B5F60389CC102F8CE77 (void);
// 0x0000004D System.Void Shooter::Update()
extern void Shooter_Update_mF95D0E122742F65FF3236CC03DDE9CA17DDCB7E2 (void);
// 0x0000004E System.Void Shooter::ShootTimer()
extern void Shooter_ShootTimer_m06D777CE36D115A77D646FF3AF1CBF04ED1B29FA (void);
// 0x0000004F System.Void Shooter::EnemyFire()
extern void Shooter_EnemyFire_mE7AD6CB3ABAE005C58F83F07185FBA5EF6265436 (void);
// 0x00000050 System.Void Shooter::.ctor()
extern void Shooter__ctor_m173C774BF5668018A0B10ACA4BB5A6DA3A6BAF2D (void);
// 0x00000051 System.Void Shredder::OnCollisionEnter2D(UnityEngine.Collision2D)
extern void Shredder_OnCollisionEnter2D_mEFFD6265C75EB9CEE9F0C7829ECB37242BEA46E8 (void);
// 0x00000052 System.Void Shredder::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void Shredder_OnTriggerEnter2D_m8DC73A33305BB3E2FA7ECE4E020A125D5250F2C3 (void);
// 0x00000053 System.Void Shredder::ShredderInteract(DamageDealer)
extern void Shredder_ShredderInteract_mBBBF1C0B2B330241CD5E8C6302E738162FBD11E2 (void);
// 0x00000054 System.Void Shredder::.ctor()
extern void Shredder__ctor_m922786FE7078C6FBE75A0247FCE5375A1FFB1B7D (void);
// 0x00000055 UnityEngine.GameObject WaveConfiguration::GetObstaclePrefab()
extern void WaveConfiguration_GetObstaclePrefab_m87A5C4B6E6C9DEC96B7E3FCE63E2ACE9C254E5F5 (void);
// 0x00000056 System.Collections.Generic.List`1<UnityEngine.Transform> WaveConfiguration::GetWaypoints()
extern void WaveConfiguration_GetWaypoints_m1032E2240489728BF55FBAFA18A7F0DDD6513196 (void);
// 0x00000057 System.Single WaveConfiguration::GetTimeBetweenObstacles()
extern void WaveConfiguration_GetTimeBetweenObstacles_m85D06A3755542B88FB36DE89BAFB3C3835B52B87 (void);
// 0x00000058 System.Single WaveConfiguration::GetNumberOfObstacles()
extern void WaveConfiguration_GetNumberOfObstacles_mF9AA4BA953B4911DE8637DC67779F9F453D4D3A9 (void);
// 0x00000059 System.Single WaveConfiguration::GetObstacleMoveSpeed()
extern void WaveConfiguration_GetObstacleMoveSpeed_mDCD364918C2E9B8E9853E62C958D2C59F41BE46B (void);
// 0x0000005A System.Void WaveConfiguration::Start()
extern void WaveConfiguration_Start_m3E9B2F54559C7360295BF2E852413172097A5F48 (void);
// 0x0000005B System.Void WaveConfiguration::Update()
extern void WaveConfiguration_Update_m141C31E4126A335BCBB715EC952E48C2BE6672D2 (void);
// 0x0000005C System.Void WaveConfiguration::.ctor()
extern void WaveConfiguration__ctor_mA7D4F52B520BFF6B452CF7A882A33DA5E7D8C8A6 (void);
static Il2CppMethodPointer s_methodPointers[92] = 
{
	BGScroll_Start_m43855E2416C592E8F9123C7B82C0426632810E43,
	BGScroll_Update_m8B0F5DB3DE39C4F9B0624180E249DC0592EE1BD3,
	BGScroll__ctor_mFAF501D0B700247D22710CBA8015A0ED75C2035C,
	DamageDealer_GetDamage_mACE71A6C2E3690BD4B5573A247846EDDE0BF7C9A,
	DamageDealer_Hit_m25098E8BE8713BACB0B71CBCA7638785E013FD2C,
	DamageDealer_Die_mBD1BF608F538507E428815B57CB7876226AF9E3C,
	DamageDealer__ctor_m089537C3DC7DE8C9FE32928F59784268ED3B3F2A,
	GameSession_Awake_m7DA48EED2DD2C071B858C834D8EE6F4BAD3890E6,
	GameSession_Update_mC5CC7FB854246A3D506D3111D5EE6B7737D181E3,
	GameSession_SetUpSingleton_m3EBBFD4F49CBAE3FF13F8EE16DF19D53DB43DAA8,
	GameSession_AddToScore_m25B41713BA1B9089BD1E3E644D71951C6DBBEE14,
	GameSession_GetScore_m261421177B31C07760F0942659EDCC341C24E7FD,
	GameSession_ResetGame_m5AAA74149896637E8655D08CFC4F8FA11F92A152,
	GameSession_PointCheck_m37E733DF7529327B141B68E7987791F38D3214A3,
	GameSession__ctor_m7A23EA1283AFD52547E4A98A8B368566F0F3DC9D,
	HealthDisplay_Start_mEB17D54FB168B486E96767626AAF4E21752F040F,
	HealthDisplay_Update_m352632E07747035D6053D01EACAF7EECE5E6F5E9,
	HealthDisplay__ctor_mCAE6A5E5DB1C29BF2340D5BEFEF395929317BF75,
	Level_WaitAndLoad_m247CF14285F9A3D2A571824CC832485FA1970CCE,
	Level_LoadStartMenu_m1FA3148093140D616278E650D0801420CD5CA9F8,
	Level_LoadGame_m37B99D4AF36E778ADFCD54326003A392941A32CB,
	Level_LoadGameOver_mD8D2FF13AD824851031F3C9396CFF0467D1BD072,
	Level_QuitGame_m49D8506FD999542FDAE47BA04B556B2332A53F5D,
	Level_PlayerWins_mF342E40855606963D236F8153012B99DE6267AF1,
	Level__ctor_mBBC9E192AD5FC6CC5FA5DFA55E8CA13E182C353A,
	U3CWaitAndLoadU3Ed__1__ctor_m5F71A2BAEEC015A2CC4DC0721B5F7E29E8F3DF5F,
	U3CWaitAndLoadU3Ed__1_System_IDisposable_Dispose_mEB8874538846D128D2BEA5DB4CE26625486C7FCB,
	U3CWaitAndLoadU3Ed__1_MoveNext_m9988CA5B69AF251F5259736506920CA496587712,
	U3CWaitAndLoadU3Ed__1_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m86594924B08710474A36F8F934158923601C4CFA,
	U3CWaitAndLoadU3Ed__1_System_Collections_IEnumerator_Reset_m6475A7C30FF91F5C08ECD0CE8340D0706D32D755,
	U3CWaitAndLoadU3Ed__1_System_Collections_IEnumerator_get_Current_m4FDEEA9F719E60EA6B4EE05B443464E683F417F0,
	MusicPlayer_Awake_mA60904394C1725C664514BD13BA55F8CEC17D6F0,
	MusicPlayer_SetUpSingleton_m19A6DE140ED2A0F7B4E06592123C60FC8CCAA60B,
	MusicPlayer_Update_m7BD87702BA93E1CE0DA8D666975B48BF5ABC376E,
	MusicPlayer__ctor_mA83600A144210E8586F4618ED75C614BFE6450FC,
	ObstaclePath_Start_m85867EC8D0ABD86BD834F3D26DEC616A76BFA187,
	ObstaclePath_Update_mCDF81CAC68CBD2ACDB9D383D5C4C35B08181FE67,
	ObstaclePath_ObstacleMove_m66A4F8BDF7745ABEE4D3905A46DDDB95F2531D93,
	ObstaclePath_SetWaveConfiguration_mCADABA412E031409B2D1996B5EDE8206FFFCB057,
	ObstaclePath__ctor_mB7995AD1B77C35CD3948C855656B1E52CED488DD,
	ObstacleSpawner_Start_mC70CACAF9BE51DD2DEA9E668B51E4D542DDC338A,
	ObstacleSpawner_SpawnAllObstaclesInWave_m13A6583AD28314CCBDD63EE7C27F33FA1163DBEE,
	ObstacleSpawner_SpawnAllWaves_mCF24E97F2DAE934D0A04AFDFB8340306A798D043,
	ObstacleSpawner__ctor_m347D7FB8C7FAEB149F02F9A147EE7E51A28F57ED,
	U3CStartU3Ed__2__ctor_mEFAF09649F1D95A91B0A017558D0300F7D5A24B2,
	U3CStartU3Ed__2_System_IDisposable_Dispose_m15038C7B9B231A52FE4EF065FB6B1B329247FD9E,
	U3CStartU3Ed__2_MoveNext_mC10E97A5BF1691D20448A6A46648AAEBBFF2F5BD,
	U3CStartU3Ed__2_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8C4C2711353CEF85D592B351EC2AFBD253D165F0,
	U3CStartU3Ed__2_System_Collections_IEnumerator_Reset_m9BDF3D9F7A5D489C24586360E8BB7818D42D0B62,
	U3CStartU3Ed__2_System_Collections_IEnumerator_get_Current_mE3888933876E6E4062B1712206966E16642B7A36,
	U3CSpawnAllObstaclesInWaveU3Ed__3__ctor_mF59D226A47B1AEED02FFE7AB7334F9C4B04C85E3,
	U3CSpawnAllObstaclesInWaveU3Ed__3_System_IDisposable_Dispose_m720B77284C4922626E0405F3D49F4F9336A8BB9C,
	U3CSpawnAllObstaclesInWaveU3Ed__3_MoveNext_m933598324F47DFE7B83B93174CE27258EB0E2D10,
	U3CSpawnAllObstaclesInWaveU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m99AF51248408CF1347686FD783C7FAED881A77ED,
	U3CSpawnAllObstaclesInWaveU3Ed__3_System_Collections_IEnumerator_Reset_m8A947A888C19B04F7B1815E1EC7B3B3315191681,
	U3CSpawnAllObstaclesInWaveU3Ed__3_System_Collections_IEnumerator_get_Current_m396C65050424725F350BA5AE3E0BD17C09469F31,
	U3CSpawnAllWavesU3Ed__4__ctor_mB4D2C5AFA037D17EEA248003C7CFB445A6826C7F,
	U3CSpawnAllWavesU3Ed__4_System_IDisposable_Dispose_m6982CFEC8B2DC3E25D4C15CC303D6D18094ECC62,
	U3CSpawnAllWavesU3Ed__4_MoveNext_mD658B71A193733F1029CBBCF3D534F63FF561958,
	U3CSpawnAllWavesU3Ed__4_U3CU3Em__Finally1_m7D542661A509E7762C6725BC04599F4D71AD8A14,
	U3CSpawnAllWavesU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m4A31DC2E73ABFB5501DBB1139E13AFC9A0168CE9,
	U3CSpawnAllWavesU3Ed__4_System_Collections_IEnumerator_Reset_m082C690DECCB9B85D78F03D7370BBBF4177337A9,
	U3CSpawnAllWavesU3Ed__4_System_Collections_IEnumerator_get_Current_m7D4489F3C07BA1FA402321009DD161CC8BD4C2EB,
	Player_Start_mBD692B64AAC791B93A589E7D3596F36787EAF021,
	Player_Update_mBA04F1D6FE3C18037EA95DFAEEAA9977BFD49CD3,
	Player_GetHealth_m258C63EDD1D293DA477E9D375D04AF88598B75E5,
	Player_BounderiesMovement_m3FEF21D18B3136F367A413341D621711979CEB8D,
	Player_Movement_m8903F38060709B703B2329E508BA6A885AFF387B,
	Player_OnTriggerEnter2D_mAF357F7244427CB9EADB81B5A6C4F0AF481641D0,
	Player_ProcessHit_mCBFF65ACF52F604E30DA7B868C6D57597E5A46EA,
	Player_Die_m16A200929DBDF9FF88C8191A26327C2CCCC80C19,
	Player__ctor_mDE8EB5B351975D4E7E24DE341B8B49B8A29CC2B7,
	ScoreDisplay_Start_m18A9D066FCD5D2688F589FDD814B56EB48182E7F,
	ScoreDisplay_Update_m104674478C444000FAD9F531723CB626CAD7B82F,
	ScoreDisplay__ctor_m7BAE440B77B8FCE54475EBC1CDB2E82937E17496,
	Shooter_Start_mBA83984BC9920FA1D7FF4B5F60389CC102F8CE77,
	Shooter_Update_mF95D0E122742F65FF3236CC03DDE9CA17DDCB7E2,
	Shooter_ShootTimer_m06D777CE36D115A77D646FF3AF1CBF04ED1B29FA,
	Shooter_EnemyFire_mE7AD6CB3ABAE005C58F83F07185FBA5EF6265436,
	Shooter__ctor_m173C774BF5668018A0B10ACA4BB5A6DA3A6BAF2D,
	Shredder_OnCollisionEnter2D_mEFFD6265C75EB9CEE9F0C7829ECB37242BEA46E8,
	Shredder_OnTriggerEnter2D_m8DC73A33305BB3E2FA7ECE4E020A125D5250F2C3,
	Shredder_ShredderInteract_mBBBF1C0B2B330241CD5E8C6302E738162FBD11E2,
	Shredder__ctor_m922786FE7078C6FBE75A0247FCE5375A1FFB1B7D,
	WaveConfiguration_GetObstaclePrefab_m87A5C4B6E6C9DEC96B7E3FCE63E2ACE9C254E5F5,
	WaveConfiguration_GetWaypoints_m1032E2240489728BF55FBAFA18A7F0DDD6513196,
	WaveConfiguration_GetTimeBetweenObstacles_m85D06A3755542B88FB36DE89BAFB3C3835B52B87,
	WaveConfiguration_GetNumberOfObstacles_mF9AA4BA953B4911DE8637DC67779F9F453D4D3A9,
	WaveConfiguration_GetObstacleMoveSpeed_mDCD364918C2E9B8E9853E62C958D2C59F41BE46B,
	WaveConfiguration_Start_m3E9B2F54559C7360295BF2E852413172097A5F48,
	WaveConfiguration_Update_m141C31E4126A335BCBB715EC952E48C2BE6672D2,
	WaveConfiguration__ctor_mA7D4F52B520BFF6B452CF7A882A33DA5E7D8C8A6,
};
static const int32_t s_InvokerIndices[92] = 
{
	23,
	23,
	23,
	10,
	23,
	23,
	23,
	23,
	23,
	23,
	32,
	10,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	102,
	14,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	14,
	28,
	14,
	23,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	14,
	23,
	14,
	32,
	23,
	102,
	23,
	14,
	23,
	14,
	23,
	23,
	10,
	23,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	26,
	23,
	14,
	14,
	655,
	655,
	655,
	23,
	23,
	23,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	92,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
