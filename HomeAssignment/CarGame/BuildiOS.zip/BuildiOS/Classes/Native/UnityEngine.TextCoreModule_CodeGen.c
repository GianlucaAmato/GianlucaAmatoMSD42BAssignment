﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngine.TextCore.FaceInfo::set_familyName(System.String)
extern void FaceInfo_set_familyName_mF2284C683441750136664CE2F54A6A1B8D025BCF_AdjustorThunk (void);
// 0x00000002 System.Void UnityEngine.TextCore.FaceInfo::set_styleName(System.String)
extern void FaceInfo_set_styleName_m2EA494E818600812D1EF63E1B861D930D72DDB2F_AdjustorThunk (void);
// 0x00000003 System.Int32 UnityEngine.TextCore.FaceInfo::get_pointSize()
extern void FaceInfo_get_pointSize_m3C6775E1AE5F27EAAB93CC84480B14AFBDB5E330_AdjustorThunk (void);
// 0x00000004 System.Void UnityEngine.TextCore.FaceInfo::set_pointSize(System.Int32)
extern void FaceInfo_set_pointSize_m26A4A24116D162BB182959D46AB2FA6576A84CF9_AdjustorThunk (void);
// 0x00000005 System.Single UnityEngine.TextCore.FaceInfo::get_scale()
extern void FaceInfo_get_scale_mA059FCEE1F13BBDF846AB8D8B8EDA468F4FCD2A4_AdjustorThunk (void);
// 0x00000006 System.Void UnityEngine.TextCore.FaceInfo::set_scale(System.Single)
extern void FaceInfo_set_scale_mA870178A90FC90A4E7D7149972CF190112244D9C_AdjustorThunk (void);
// 0x00000007 System.Single UnityEngine.TextCore.FaceInfo::get_lineHeight()
extern void FaceInfo_get_lineHeight_m4BC0162351D2C7E607ECDF93534DAF0169AAEFE5_AdjustorThunk (void);
// 0x00000008 System.Void UnityEngine.TextCore.FaceInfo::set_lineHeight(System.Single)
extern void FaceInfo_set_lineHeight_mF771EE64A254D4ED012070BDC94B06545668D347_AdjustorThunk (void);
// 0x00000009 System.Single UnityEngine.TextCore.FaceInfo::get_ascentLine()
extern void FaceInfo_get_ascentLine_m69928E2E998FA9441C7628BF7F8D9E888470D983_AdjustorThunk (void);
// 0x0000000A System.Void UnityEngine.TextCore.FaceInfo::set_ascentLine(System.Single)
extern void FaceInfo_set_ascentLine_m510C3CF1B961D9BEDD79A4BAA7D65742C33AAD06_AdjustorThunk (void);
// 0x0000000B System.Single UnityEngine.TextCore.FaceInfo::get_capLine()
extern void FaceInfo_get_capLine_m16556D45E8441052D15DAE83CDB3FC31635BE0A7_AdjustorThunk (void);
// 0x0000000C System.Void UnityEngine.TextCore.FaceInfo::set_capLine(System.Single)
extern void FaceInfo_set_capLine_m6FB88B8953008824E84DBA88B3896DD98A1E8926_AdjustorThunk (void);
// 0x0000000D System.Single UnityEngine.TextCore.FaceInfo::get_meanLine()
extern void FaceInfo_get_meanLine_m10957577CE99FF794523FA34E4ED873B4888A11D_AdjustorThunk (void);
// 0x0000000E System.Void UnityEngine.TextCore.FaceInfo::set_meanLine(System.Single)
extern void FaceInfo_set_meanLine_m9118E1C37F756267BF93CE1E94C880FACB70E2A2_AdjustorThunk (void);
// 0x0000000F System.Single UnityEngine.TextCore.FaceInfo::get_baseline()
extern void FaceInfo_get_baseline_m7EB9429D8D329E5DA5DB890CEF02A6C015C056D6_AdjustorThunk (void);
// 0x00000010 System.Void UnityEngine.TextCore.FaceInfo::set_baseline(System.Single)
extern void FaceInfo_set_baseline_m83DA240FEADBE11609EB11B79AC9FE6165ABBAC7_AdjustorThunk (void);
// 0x00000011 System.Single UnityEngine.TextCore.FaceInfo::get_descentLine()
extern void FaceInfo_get_descentLine_m0AEF0D85997836B841605DCE178ABA42A92C6EFA_AdjustorThunk (void);
// 0x00000012 System.Void UnityEngine.TextCore.FaceInfo::set_descentLine(System.Single)
extern void FaceInfo_set_descentLine_m91AB76A124FE9E536BD72785512B2C623BA2B067_AdjustorThunk (void);
// 0x00000013 System.Single UnityEngine.TextCore.FaceInfo::get_superscriptOffset()
extern void FaceInfo_get_superscriptOffset_mAF8D37F78A79780652BAE40384F0C4DED8350769_AdjustorThunk (void);
// 0x00000014 System.Void UnityEngine.TextCore.FaceInfo::set_superscriptOffset(System.Single)
extern void FaceInfo_set_superscriptOffset_mE0422507D4C2DE3F2CFF7286F90462675741D15E_AdjustorThunk (void);
// 0x00000015 System.Single UnityEngine.TextCore.FaceInfo::get_superscriptSize()
extern void FaceInfo_get_superscriptSize_m7FBEC1B0C97A7DC9D581AF9ADBDDCF14F7565F1A_AdjustorThunk (void);
// 0x00000016 System.Void UnityEngine.TextCore.FaceInfo::set_superscriptSize(System.Single)
extern void FaceInfo_set_superscriptSize_mCDE84F4EA47D69B7D783FE62DA78656BBC17C07E_AdjustorThunk (void);
// 0x00000017 System.Single UnityEngine.TextCore.FaceInfo::get_subscriptOffset()
extern void FaceInfo_get_subscriptOffset_mD3F7F2F5F93364977E3F81E9B693D5CDB1419088_AdjustorThunk (void);
// 0x00000018 System.Void UnityEngine.TextCore.FaceInfo::set_subscriptOffset(System.Single)
extern void FaceInfo_set_subscriptOffset_mCF79D815311C70E3E8CC2BC241FEFE39CC992A39_AdjustorThunk (void);
// 0x00000019 System.Single UnityEngine.TextCore.FaceInfo::get_subscriptSize()
extern void FaceInfo_get_subscriptSize_mEC9AEAD24A51AB19FFCC09AE919EF656ED2C6413_AdjustorThunk (void);
// 0x0000001A System.Void UnityEngine.TextCore.FaceInfo::set_subscriptSize(System.Single)
extern void FaceInfo_set_subscriptSize_m61497C0D29FE50D498648DEC0FAADA9ED151387A_AdjustorThunk (void);
// 0x0000001B System.Single UnityEngine.TextCore.FaceInfo::get_underlineOffset()
extern void FaceInfo_get_underlineOffset_m0F2900E06388C697807D43285BD4979E9D0BDA50_AdjustorThunk (void);
// 0x0000001C System.Void UnityEngine.TextCore.FaceInfo::set_underlineOffset(System.Single)
extern void FaceInfo_set_underlineOffset_mBE89D25E848FAF83FB750D95A93F6C051D798B54_AdjustorThunk (void);
// 0x0000001D System.Single UnityEngine.TextCore.FaceInfo::get_underlineThickness()
extern void FaceInfo_get_underlineThickness_m07A6016172DE8DC1514CA780EBB80C32FA209F28_AdjustorThunk (void);
// 0x0000001E System.Void UnityEngine.TextCore.FaceInfo::set_underlineThickness(System.Single)
extern void FaceInfo_set_underlineThickness_m86B440DB7CBDB6C588FBC03990B980A715726059_AdjustorThunk (void);
// 0x0000001F System.Single UnityEngine.TextCore.FaceInfo::get_strikethroughOffset()
extern void FaceInfo_get_strikethroughOffset_m705C7A75FFA7E324582D6A1CC404ED4C8E8417EB_AdjustorThunk (void);
// 0x00000020 System.Void UnityEngine.TextCore.FaceInfo::set_strikethroughOffset(System.Single)
extern void FaceInfo_set_strikethroughOffset_m9ACD0A24A8EC5FEB90596BA43E8E8D8FF7EA0623_AdjustorThunk (void);
// 0x00000021 System.Void UnityEngine.TextCore.FaceInfo::set_strikethroughThickness(System.Single)
extern void FaceInfo_set_strikethroughThickness_mE26FAFBC6C984F88F68F7507CFE8AFB28E1932E7_AdjustorThunk (void);
// 0x00000022 System.Single UnityEngine.TextCore.FaceInfo::get_tabWidth()
extern void FaceInfo_get_tabWidth_mFBE94B2FBBB301B0FC1011D49A96032A0EE1A588_AdjustorThunk (void);
// 0x00000023 System.Void UnityEngine.TextCore.FaceInfo::set_tabWidth(System.Single)
extern void FaceInfo_set_tabWidth_mE024C95E768A214E3C85781753658B437F4B6B54_AdjustorThunk (void);
// 0x00000024 System.Int32 UnityEngine.TextCore.GlyphRect::get_x()
extern void GlyphRect_get_x_m004398D85360A389BCCD4F8B38347C0555F86166_AdjustorThunk (void);
// 0x00000025 System.Int32 UnityEngine.TextCore.GlyphRect::get_y()
extern void GlyphRect_get_y_mBF2FC84CB7B201F30376B46390D37887B6AD6C20_AdjustorThunk (void);
// 0x00000026 System.Int32 UnityEngine.TextCore.GlyphRect::get_width()
extern void GlyphRect_get_width_m8B9FBFA897082BA8E5F71222E1AAAB8D4A345A41_AdjustorThunk (void);
// 0x00000027 System.Int32 UnityEngine.TextCore.GlyphRect::get_height()
extern void GlyphRect_get_height_m319E96AD96E2087C9C9F5A1DF883F06A4D04104F_AdjustorThunk (void);
// 0x00000028 UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.GlyphRect::get_zero()
extern void GlyphRect_get_zero_m4F82533B1FF0E143D6CEB594F68254D925879229 (void);
// 0x00000029 System.Void UnityEngine.TextCore.GlyphRect::.ctor(System.Int32,System.Int32,System.Int32,System.Int32)
extern void GlyphRect__ctor_m278B410AE9B6DE62FF8C2445B8F3C6051B45ED61_AdjustorThunk (void);
// 0x0000002A System.Int32 UnityEngine.TextCore.GlyphRect::GetHashCode()
extern void GlyphRect_GetHashCode_m6DC4515E8C489593A329B5EA66895BD8C25DF913_AdjustorThunk (void);
// 0x0000002B System.Boolean UnityEngine.TextCore.GlyphRect::Equals(System.Object)
extern void GlyphRect_Equals_m7F1DB9A21E584BEF84C5F83E6DD290EF54D655C1_AdjustorThunk (void);
// 0x0000002C System.Boolean UnityEngine.TextCore.GlyphRect::Equals(UnityEngine.TextCore.GlyphRect)
extern void GlyphRect_Equals_mB9F911262F09BC42CD2A461D8692D1C3ECAFCDCE_AdjustorThunk (void);
// 0x0000002D System.Void UnityEngine.TextCore.GlyphRect::.cctor()
extern void GlyphRect__cctor_mC0A746562E15F7DB07264227927E7B9276FA5A9B (void);
// 0x0000002E System.Single UnityEngine.TextCore.GlyphMetrics::get_width()
extern void GlyphMetrics_get_width_m4E2BCD2B54F121478C1D23C43FB6E8C0EF71C70F_AdjustorThunk (void);
// 0x0000002F System.Single UnityEngine.TextCore.GlyphMetrics::get_height()
extern void GlyphMetrics_get_height_m742B169DCF2892774ACEC4F25310CDC0C7F1D85F_AdjustorThunk (void);
// 0x00000030 System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingX()
extern void GlyphMetrics_get_horizontalBearingX_m8474B6C9DB0D4D36516FCAC03B6ECBDAF49247E0_AdjustorThunk (void);
// 0x00000031 System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingY()
extern void GlyphMetrics_get_horizontalBearingY_m2C5A73B899AFF5F5F594F447160ADB6E0523C16A_AdjustorThunk (void);
// 0x00000032 System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalAdvance()
extern void GlyphMetrics_get_horizontalAdvance_mB204F2676223D5BEF5FEFF8969B159B39F1A617A_AdjustorThunk (void);
// 0x00000033 System.Void UnityEngine.TextCore.GlyphMetrics::.ctor(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void GlyphMetrics__ctor_m6146EC37C12EF153771AEF9983A63B5EBAE0CEFB_AdjustorThunk (void);
// 0x00000034 System.Int32 UnityEngine.TextCore.GlyphMetrics::GetHashCode()
extern void GlyphMetrics_GetHashCode_m4F7985D656AFB70AE746F9A2513D39D3DFF9CD73_AdjustorThunk (void);
// 0x00000035 System.Boolean UnityEngine.TextCore.GlyphMetrics::Equals(System.Object)
extern void GlyphMetrics_Equals_mCCF68C73B7AE05D97A0D4459384DABD8BEB1097F_AdjustorThunk (void);
// 0x00000036 System.Boolean UnityEngine.TextCore.GlyphMetrics::Equals(UnityEngine.TextCore.GlyphMetrics)
extern void GlyphMetrics_Equals_m54C8D6CAD2653668377F5F7A9F78FD7C4F05E4A8_AdjustorThunk (void);
// 0x00000037 System.UInt32 UnityEngine.TextCore.Glyph::get_index()
extern void Glyph_get_index_mB9A53E02F757731DC06414DFC6F4F5D1615DC248 (void);
// 0x00000038 System.Void UnityEngine.TextCore.Glyph::set_index(System.UInt32)
extern void Glyph_set_index_m68FA74E7DF133C63E1544913F2ADC38BB27DBED4 (void);
// 0x00000039 UnityEngine.TextCore.GlyphMetrics UnityEngine.TextCore.Glyph::get_metrics()
extern void Glyph_get_metrics_m395A93D5BD1B7859DD95B17386DAA033D2F865B0 (void);
// 0x0000003A System.Void UnityEngine.TextCore.Glyph::set_metrics(UnityEngine.TextCore.GlyphMetrics)
extern void Glyph_set_metrics_mAA75ADA7FEE5D62A48D1558CE4393C8E4FBBBC3B (void);
// 0x0000003B UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.Glyph::get_glyphRect()
extern void Glyph_get_glyphRect_mA3484840AF306B3F9B146D7162424238B4F456F9 (void);
// 0x0000003C System.Void UnityEngine.TextCore.Glyph::set_glyphRect(UnityEngine.TextCore.GlyphRect)
extern void Glyph_set_glyphRect_mC1B26C50850B546BF6CF5AE5765FA6080F983B3B (void);
// 0x0000003D System.Single UnityEngine.TextCore.Glyph::get_scale()
extern void Glyph_get_scale_m446CB523D55E31B00D8AC704A60308C773E7F208 (void);
// 0x0000003E System.Void UnityEngine.TextCore.Glyph::set_scale(System.Single)
extern void Glyph_set_scale_m576BAC2DABBBDDAEB8B84BEB4A0780BC00D90753 (void);
// 0x0000003F System.Int32 UnityEngine.TextCore.Glyph::get_atlasIndex()
extern void Glyph_get_atlasIndex_m6538243B8852D859DE81213EDC5A9FDD837909EF (void);
// 0x00000040 System.Void UnityEngine.TextCore.Glyph::set_atlasIndex(System.Int32)
extern void Glyph_set_atlasIndex_m9994675326C6545B78A3CD5CC4A534D597195A3B (void);
// 0x00000041 System.Void UnityEngine.TextCore.Glyph::.ctor()
extern void Glyph__ctor_m3B14665C4F129AA87DC0FBF1D8E5274729840076 (void);
// 0x00000042 System.Void UnityEngine.TextCore.Glyph::.ctor(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct)
extern void Glyph__ctor_m926A82734800BFA828FFB469B956F563FF0F1994 (void);
// 0x00000043 System.Void UnityEngine.TextCore.Glyph::.ctor(System.UInt32,UnityEngine.TextCore.GlyphMetrics,UnityEngine.TextCore.GlyphRect,System.Single,System.Int32)
extern void Glyph__ctor_m3B1336D6A76FF3C315E66EC5857E378D7BE50DE2 (void);
// 0x00000044 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xPlacement()
extern void GlyphValueRecord_get_xPlacement_mAC5902DE9EE01D98DE9FBC6DB3A8BA7CDC525D14_AdjustorThunk (void);
// 0x00000045 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yPlacement()
extern void GlyphValueRecord_get_yPlacement_m624E2DA69CC5A21117EE275359F66AF88DFC7D2D_AdjustorThunk (void);
// 0x00000046 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xAdvance()
extern void GlyphValueRecord_get_xAdvance_m577D4D32490C42890C3F15230479D931B91BDED5_AdjustorThunk (void);
// 0x00000047 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yAdvance()
extern void GlyphValueRecord_get_yAdvance_m9659978FFA9B58B6AA7DE30199E405CF642BA34F_AdjustorThunk (void);
// 0x00000048 System.Int32 UnityEngine.TextCore.LowLevel.GlyphValueRecord::GetHashCode()
extern void GlyphValueRecord_GetHashCode_m5700595527E17C02B923199180E8983105563A71_AdjustorThunk (void);
// 0x00000049 System.Boolean UnityEngine.TextCore.LowLevel.GlyphValueRecord::Equals(System.Object)
extern void GlyphValueRecord_Equals_mB12EE7C56E781B2DAFF2DEA1AFFFA1EC4DCBA943_AdjustorThunk (void);
// 0x0000004A System.Boolean UnityEngine.TextCore.LowLevel.GlyphValueRecord::Equals(UnityEngine.TextCore.LowLevel.GlyphValueRecord)
extern void GlyphValueRecord_Equals_m716F55BA3DD7B7E97F3E35BE94A5922BE90FECF4_AdjustorThunk (void);
// 0x0000004B System.UInt32 UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphIndex()
extern void GlyphAdjustmentRecord_get_glyphIndex_mCD420C739E19E446152534AFA80A6113C0DBCC55_AdjustorThunk (void);
// 0x0000004C UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphValueRecord()
extern void GlyphAdjustmentRecord_get_glyphValueRecord_mAC27920271FB7166EE305BACE1D595CAA57872EE_AdjustorThunk (void);
// 0x0000004D UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_firstAdjustmentRecord()
extern void GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m92BC7561227D482635EF8AB93B8F20808017FBF8_AdjustorThunk (void);
// 0x0000004E UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_secondAdjustmentRecord()
extern void GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m488CCBCB6802727334E2135E65EBB027A0A01EAD_AdjustorThunk (void);
// 0x0000004F UnityEngine.TextCore.LowLevel.FontEngineError UnityEngine.TextCore.LowLevel.FontEngine::InitializeFontEngine()
extern void FontEngine_InitializeFontEngine_m85697221DC9ED18EC8356014293D423347054C43 (void);
// 0x00000050 System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::InitializeFontEngine_Internal()
extern void FontEngine_InitializeFontEngine_Internal_m50E925BB9BE850ADB0611C2707FCECF3FB728C71 (void);
// 0x00000051 UnityEngine.TextCore.LowLevel.FontEngineError UnityEngine.TextCore.LowLevel.FontEngine::LoadFontFace(UnityEngine.Font,System.Int32)
extern void FontEngine_LoadFontFace_m85674659FD8AA761C771CA869FC345B1555EDD5D (void);
// 0x00000052 System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::LoadFontFace_With_Size_FromFont_Internal(UnityEngine.Font,System.Int32)
extern void FontEngine_LoadFontFace_With_Size_FromFont_Internal_m2904823B237D890C9AC817A13098274D7DEC4FA7 (void);
// 0x00000053 UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.LowLevel.FontEngine::GetFaceInfo()
extern void FontEngine_GetFaceInfo_m76A5E8DEE1846A7D56BC72D8FE177CA6656F8385 (void);
// 0x00000054 System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::GetFaceInfo_Internal(UnityEngine.TextCore.FaceInfo&)
extern void FontEngine_GetFaceInfo_Internal_m86BF1FCC26761DEB15EBC252943F10690612F6CA (void);
// 0x00000055 System.UInt32 UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphIndex(System.UInt32)
extern void FontEngine_GetGlyphIndex_mFA9D09AB6E5FC7234F0154D9BF53923762EE1947 (void);
// 0x00000056 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithUnicodeValue(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.Glyph&)
extern void FontEngine_TryGetGlyphWithUnicodeValue_m2C8B5D37D097FB1C75846E431D29AC15349CBA3B (void);
// 0x00000057 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithUnicodeValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
extern void FontEngine_TryGetGlyphWithUnicodeValue_Internal_m4DDE3BF8F78CEDB763D821454B89997BB9BA276C (void);
// 0x00000058 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithIndexValue(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.Glyph&)
extern void FontEngine_TryGetGlyphWithIndexValue_m775B743546174CA10A01141847225874AC3EE7D9 (void);
// 0x00000059 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithIndexValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
extern void FontEngine_TryGetGlyphWithIndexValue_Internal_mF1CB9EABC97E1A1372A23297EAFBE7EAB5A6313A (void);
// 0x0000005A System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphToTexture(System.UInt32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.Glyph&)
extern void FontEngine_TryAddGlyphToTexture_mF2513F6DE362FCB9609BE09CC1EFB6D851922200 (void);
// 0x0000005B System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphToTexture_Internal(System.UInt32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
extern void FontEngine_TryAddGlyphToTexture_Internal_m1A0E3323EADB617657BF97F660649C6FDD1B14B7 (void);
// 0x0000005C System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphsToTexture(System.Collections.Generic.List`1<System.UInt32>,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.Glyph[]&)
extern void FontEngine_TryAddGlyphsToTexture_m61337C5A18F0229A85A6203976715D70F3362655 (void);
// 0x0000005D System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphsToTexture_Internal(System.UInt32[],System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[],System.Int32&)
extern void FontEngine_TryAddGlyphsToTexture_Internal_mB0FE279387211C00BF9E5891C39462CD6F159CE8 (void);
// 0x0000005E UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[] UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphPairAdjustmentTable(System.UInt32[])
extern void FontEngine_GetGlyphPairAdjustmentTable_mE93C9A8673C34CAE740DEB22328F2A961DB76014 (void);
// 0x0000005F System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::PopulatePairAdjustmentRecordMarshallingArray_from_GlyphIndexes(System.UInt32[],System.Int32&)
extern void FontEngine_PopulatePairAdjustmentRecordMarshallingArray_from_GlyphIndexes_m209060A34247119B382FE9327CDDC85B8A04DEDF (void);
// 0x00000060 System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphPairAdjustmentRecordsFromMarshallingArray(UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[])
extern void FontEngine_GetGlyphPairAdjustmentRecordsFromMarshallingArray_m0B720E99C766368DA85190A049A4F70C5805DFD4 (void);
// 0x00000061 System.Void UnityEngine.TextCore.LowLevel.FontEngine::SetMarshallingArraySize(T[]&,System.Int32)
// 0x00000062 System.Void UnityEngine.TextCore.LowLevel.FontEngine::ResetAtlasTexture(UnityEngine.Texture2D)
extern void FontEngine_ResetAtlasTexture_m34415B1BC955B68AC8BFE1F339BA74E4B81C160B (void);
// 0x00000063 System.Void UnityEngine.TextCore.LowLevel.FontEngine::.cctor()
extern void FontEngine__cctor_mACF18DD12F81B34818DC5508BC4EF347445F7FE3 (void);
// 0x00000064 System.Int32 UnityEngine.TextCore.LowLevel.FontEngineUtilities::MaxValue(System.Int32,System.Int32,System.Int32)
extern void FontEngineUtilities_MaxValue_m2EF659954522080160961E35BE6FDF1DD5C98FB7 (void);
static Il2CppMethodPointer s_methodPointers[100] = 
{
	FaceInfo_set_familyName_mF2284C683441750136664CE2F54A6A1B8D025BCF_AdjustorThunk,
	FaceInfo_set_styleName_m2EA494E818600812D1EF63E1B861D930D72DDB2F_AdjustorThunk,
	FaceInfo_get_pointSize_m3C6775E1AE5F27EAAB93CC84480B14AFBDB5E330_AdjustorThunk,
	FaceInfo_set_pointSize_m26A4A24116D162BB182959D46AB2FA6576A84CF9_AdjustorThunk,
	FaceInfo_get_scale_mA059FCEE1F13BBDF846AB8D8B8EDA468F4FCD2A4_AdjustorThunk,
	FaceInfo_set_scale_mA870178A90FC90A4E7D7149972CF190112244D9C_AdjustorThunk,
	FaceInfo_get_lineHeight_m4BC0162351D2C7E607ECDF93534DAF0169AAEFE5_AdjustorThunk,
	FaceInfo_set_lineHeight_mF771EE64A254D4ED012070BDC94B06545668D347_AdjustorThunk,
	FaceInfo_get_ascentLine_m69928E2E998FA9441C7628BF7F8D9E888470D983_AdjustorThunk,
	FaceInfo_set_ascentLine_m510C3CF1B961D9BEDD79A4BAA7D65742C33AAD06_AdjustorThunk,
	FaceInfo_get_capLine_m16556D45E8441052D15DAE83CDB3FC31635BE0A7_AdjustorThunk,
	FaceInfo_set_capLine_m6FB88B8953008824E84DBA88B3896DD98A1E8926_AdjustorThunk,
	FaceInfo_get_meanLine_m10957577CE99FF794523FA34E4ED873B4888A11D_AdjustorThunk,
	FaceInfo_set_meanLine_m9118E1C37F756267BF93CE1E94C880FACB70E2A2_AdjustorThunk,
	FaceInfo_get_baseline_m7EB9429D8D329E5DA5DB890CEF02A6C015C056D6_AdjustorThunk,
	FaceInfo_set_baseline_m83DA240FEADBE11609EB11B79AC9FE6165ABBAC7_AdjustorThunk,
	FaceInfo_get_descentLine_m0AEF0D85997836B841605DCE178ABA42A92C6EFA_AdjustorThunk,
	FaceInfo_set_descentLine_m91AB76A124FE9E536BD72785512B2C623BA2B067_AdjustorThunk,
	FaceInfo_get_superscriptOffset_mAF8D37F78A79780652BAE40384F0C4DED8350769_AdjustorThunk,
	FaceInfo_set_superscriptOffset_mE0422507D4C2DE3F2CFF7286F90462675741D15E_AdjustorThunk,
	FaceInfo_get_superscriptSize_m7FBEC1B0C97A7DC9D581AF9ADBDDCF14F7565F1A_AdjustorThunk,
	FaceInfo_set_superscriptSize_mCDE84F4EA47D69B7D783FE62DA78656BBC17C07E_AdjustorThunk,
	FaceInfo_get_subscriptOffset_mD3F7F2F5F93364977E3F81E9B693D5CDB1419088_AdjustorThunk,
	FaceInfo_set_subscriptOffset_mCF79D815311C70E3E8CC2BC241FEFE39CC992A39_AdjustorThunk,
	FaceInfo_get_subscriptSize_mEC9AEAD24A51AB19FFCC09AE919EF656ED2C6413_AdjustorThunk,
	FaceInfo_set_subscriptSize_m61497C0D29FE50D498648DEC0FAADA9ED151387A_AdjustorThunk,
	FaceInfo_get_underlineOffset_m0F2900E06388C697807D43285BD4979E9D0BDA50_AdjustorThunk,
	FaceInfo_set_underlineOffset_mBE89D25E848FAF83FB750D95A93F6C051D798B54_AdjustorThunk,
	FaceInfo_get_underlineThickness_m07A6016172DE8DC1514CA780EBB80C32FA209F28_AdjustorThunk,
	FaceInfo_set_underlineThickness_m86B440DB7CBDB6C588FBC03990B980A715726059_AdjustorThunk,
	FaceInfo_get_strikethroughOffset_m705C7A75FFA7E324582D6A1CC404ED4C8E8417EB_AdjustorThunk,
	FaceInfo_set_strikethroughOffset_m9ACD0A24A8EC5FEB90596BA43E8E8D8FF7EA0623_AdjustorThunk,
	FaceInfo_set_strikethroughThickness_mE26FAFBC6C984F88F68F7507CFE8AFB28E1932E7_AdjustorThunk,
	FaceInfo_get_tabWidth_mFBE94B2FBBB301B0FC1011D49A96032A0EE1A588_AdjustorThunk,
	FaceInfo_set_tabWidth_mE024C95E768A214E3C85781753658B437F4B6B54_AdjustorThunk,
	GlyphRect_get_x_m004398D85360A389BCCD4F8B38347C0555F86166_AdjustorThunk,
	GlyphRect_get_y_mBF2FC84CB7B201F30376B46390D37887B6AD6C20_AdjustorThunk,
	GlyphRect_get_width_m8B9FBFA897082BA8E5F71222E1AAAB8D4A345A41_AdjustorThunk,
	GlyphRect_get_height_m319E96AD96E2087C9C9F5A1DF883F06A4D04104F_AdjustorThunk,
	GlyphRect_get_zero_m4F82533B1FF0E143D6CEB594F68254D925879229,
	GlyphRect__ctor_m278B410AE9B6DE62FF8C2445B8F3C6051B45ED61_AdjustorThunk,
	GlyphRect_GetHashCode_m6DC4515E8C489593A329B5EA66895BD8C25DF913_AdjustorThunk,
	GlyphRect_Equals_m7F1DB9A21E584BEF84C5F83E6DD290EF54D655C1_AdjustorThunk,
	GlyphRect_Equals_mB9F911262F09BC42CD2A461D8692D1C3ECAFCDCE_AdjustorThunk,
	GlyphRect__cctor_mC0A746562E15F7DB07264227927E7B9276FA5A9B,
	GlyphMetrics_get_width_m4E2BCD2B54F121478C1D23C43FB6E8C0EF71C70F_AdjustorThunk,
	GlyphMetrics_get_height_m742B169DCF2892774ACEC4F25310CDC0C7F1D85F_AdjustorThunk,
	GlyphMetrics_get_horizontalBearingX_m8474B6C9DB0D4D36516FCAC03B6ECBDAF49247E0_AdjustorThunk,
	GlyphMetrics_get_horizontalBearingY_m2C5A73B899AFF5F5F594F447160ADB6E0523C16A_AdjustorThunk,
	GlyphMetrics_get_horizontalAdvance_mB204F2676223D5BEF5FEFF8969B159B39F1A617A_AdjustorThunk,
	GlyphMetrics__ctor_m6146EC37C12EF153771AEF9983A63B5EBAE0CEFB_AdjustorThunk,
	GlyphMetrics_GetHashCode_m4F7985D656AFB70AE746F9A2513D39D3DFF9CD73_AdjustorThunk,
	GlyphMetrics_Equals_mCCF68C73B7AE05D97A0D4459384DABD8BEB1097F_AdjustorThunk,
	GlyphMetrics_Equals_m54C8D6CAD2653668377F5F7A9F78FD7C4F05E4A8_AdjustorThunk,
	Glyph_get_index_mB9A53E02F757731DC06414DFC6F4F5D1615DC248,
	Glyph_set_index_m68FA74E7DF133C63E1544913F2ADC38BB27DBED4,
	Glyph_get_metrics_m395A93D5BD1B7859DD95B17386DAA033D2F865B0,
	Glyph_set_metrics_mAA75ADA7FEE5D62A48D1558CE4393C8E4FBBBC3B,
	Glyph_get_glyphRect_mA3484840AF306B3F9B146D7162424238B4F456F9,
	Glyph_set_glyphRect_mC1B26C50850B546BF6CF5AE5765FA6080F983B3B,
	Glyph_get_scale_m446CB523D55E31B00D8AC704A60308C773E7F208,
	Glyph_set_scale_m576BAC2DABBBDDAEB8B84BEB4A0780BC00D90753,
	Glyph_get_atlasIndex_m6538243B8852D859DE81213EDC5A9FDD837909EF,
	Glyph_set_atlasIndex_m9994675326C6545B78A3CD5CC4A534D597195A3B,
	Glyph__ctor_m3B14665C4F129AA87DC0FBF1D8E5274729840076,
	Glyph__ctor_m926A82734800BFA828FFB469B956F563FF0F1994,
	Glyph__ctor_m3B1336D6A76FF3C315E66EC5857E378D7BE50DE2,
	GlyphValueRecord_get_xPlacement_mAC5902DE9EE01D98DE9FBC6DB3A8BA7CDC525D14_AdjustorThunk,
	GlyphValueRecord_get_yPlacement_m624E2DA69CC5A21117EE275359F66AF88DFC7D2D_AdjustorThunk,
	GlyphValueRecord_get_xAdvance_m577D4D32490C42890C3F15230479D931B91BDED5_AdjustorThunk,
	GlyphValueRecord_get_yAdvance_m9659978FFA9B58B6AA7DE30199E405CF642BA34F_AdjustorThunk,
	GlyphValueRecord_GetHashCode_m5700595527E17C02B923199180E8983105563A71_AdjustorThunk,
	GlyphValueRecord_Equals_mB12EE7C56E781B2DAFF2DEA1AFFFA1EC4DCBA943_AdjustorThunk,
	GlyphValueRecord_Equals_m716F55BA3DD7B7E97F3E35BE94A5922BE90FECF4_AdjustorThunk,
	GlyphAdjustmentRecord_get_glyphIndex_mCD420C739E19E446152534AFA80A6113C0DBCC55_AdjustorThunk,
	GlyphAdjustmentRecord_get_glyphValueRecord_mAC27920271FB7166EE305BACE1D595CAA57872EE_AdjustorThunk,
	GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m92BC7561227D482635EF8AB93B8F20808017FBF8_AdjustorThunk,
	GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m488CCBCB6802727334E2135E65EBB027A0A01EAD_AdjustorThunk,
	FontEngine_InitializeFontEngine_m85697221DC9ED18EC8356014293D423347054C43,
	FontEngine_InitializeFontEngine_Internal_m50E925BB9BE850ADB0611C2707FCECF3FB728C71,
	FontEngine_LoadFontFace_m85674659FD8AA761C771CA869FC345B1555EDD5D,
	FontEngine_LoadFontFace_With_Size_FromFont_Internal_m2904823B237D890C9AC817A13098274D7DEC4FA7,
	FontEngine_GetFaceInfo_m76A5E8DEE1846A7D56BC72D8FE177CA6656F8385,
	FontEngine_GetFaceInfo_Internal_m86BF1FCC26761DEB15EBC252943F10690612F6CA,
	FontEngine_GetGlyphIndex_mFA9D09AB6E5FC7234F0154D9BF53923762EE1947,
	FontEngine_TryGetGlyphWithUnicodeValue_m2C8B5D37D097FB1C75846E431D29AC15349CBA3B,
	FontEngine_TryGetGlyphWithUnicodeValue_Internal_m4DDE3BF8F78CEDB763D821454B89997BB9BA276C,
	FontEngine_TryGetGlyphWithIndexValue_m775B743546174CA10A01141847225874AC3EE7D9,
	FontEngine_TryGetGlyphWithIndexValue_Internal_mF1CB9EABC97E1A1372A23297EAFBE7EAB5A6313A,
	FontEngine_TryAddGlyphToTexture_mF2513F6DE362FCB9609BE09CC1EFB6D851922200,
	FontEngine_TryAddGlyphToTexture_Internal_m1A0E3323EADB617657BF97F660649C6FDD1B14B7,
	FontEngine_TryAddGlyphsToTexture_m61337C5A18F0229A85A6203976715D70F3362655,
	FontEngine_TryAddGlyphsToTexture_Internal_mB0FE279387211C00BF9E5891C39462CD6F159CE8,
	FontEngine_GetGlyphPairAdjustmentTable_mE93C9A8673C34CAE740DEB22328F2A961DB76014,
	FontEngine_PopulatePairAdjustmentRecordMarshallingArray_from_GlyphIndexes_m209060A34247119B382FE9327CDDC85B8A04DEDF,
	FontEngine_GetGlyphPairAdjustmentRecordsFromMarshallingArray_m0B720E99C766368DA85190A049A4F70C5805DFD4,
	NULL,
	FontEngine_ResetAtlasTexture_m34415B1BC955B68AC8BFE1F339BA74E4B81C160B,
	FontEngine__cctor_mACF18DD12F81B34818DC5508BC4EF347445F7FE3,
	FontEngineUtilities_MaxValue_m2EF659954522080160961E35BE6FDF1DD5C98FB7,
};
static const int32_t s_InvokerIndices[100] = 
{
	26,
	26,
	10,
	32,
	655,
	275,
	655,
	275,
	655,
	275,
	655,
	275,
	655,
	275,
	655,
	275,
	655,
	275,
	655,
	275,
	655,
	275,
	655,
	275,
	655,
	275,
	655,
	275,
	655,
	275,
	655,
	275,
	275,
	655,
	275,
	10,
	10,
	10,
	10,
	1345,
	279,
	10,
	9,
	1346,
	3,
	655,
	655,
	655,
	655,
	655,
	1347,
	10,
	9,
	1348,
	10,
	32,
	1349,
	1350,
	1351,
	1352,
	655,
	275,
	10,
	32,
	23,
	1353,
	1354,
	655,
	655,
	655,
	655,
	10,
	9,
	1355,
	10,
	1356,
	1357,
	1357,
	515,
	515,
	171,
	171,
	1358,
	427,
	21,
	1359,
	1359,
	1359,
	1359,
	1360,
	1361,
	1362,
	1363,
	0,
	572,
	186,
	-1,
	111,
	3,
	158,
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x06000061, { 0, 2 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[2] = 
{
	{ (Il2CppRGCTXDataType)2, 7107 },
	{ (Il2CppRGCTXDataType)3, 8385 },
};
extern const Il2CppCodeGenModule g_UnityEngine_TextCoreModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_TextCoreModuleCodeGenModule = 
{
	"UnityEngine.TextCoreModule.dll",
	100,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	1,
	s_rgctxIndices,
	2,
	s_rgctxValues,
	NULL,
};
